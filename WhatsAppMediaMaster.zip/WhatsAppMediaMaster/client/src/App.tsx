import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { WhatsAppProvider } from "./context/WhatsAppContext";
import Layout from "./components/Layout";
import ConnectionPage from "./pages/ConnectionPage";
import MediaDownloadPage from "./pages/MediaDownloadPage";
import AutoMessagingPage from "./pages/AutoMessagingPage";
import UnreadManagementPage from "./pages/UnreadManagementPage";
import DownloadHistoryPage from "./pages/DownloadHistoryPage";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={ConnectionPage} />
        <Route path="/download" component={MediaDownloadPage} />
        <Route path="/messaging" component={AutoMessagingPage} />
        <Route path="/unread" component={UnreadManagementPage} />
        <Route path="/history" component={DownloadHistoryPage} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WhatsAppProvider>
        <Router />
        <Toaster />
      </WhatsAppProvider>
    </QueryClientProvider>
  );
}

export default App;
