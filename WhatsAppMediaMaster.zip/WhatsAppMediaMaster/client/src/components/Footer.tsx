import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-surface shadow-card h-10 flex items-center px-6 text-xs text-gray-500">
      <div>WhatsApp Media Manager v1.0.0</div>
      <div className="ml-auto flex items-center space-x-4">
        <span>Storage: 3.8 GB / 10 GB</span>
        <span>© 2023 WhatsApp Media Manager</span>
      </div>
    </footer>
  );
};

export default Footer;
