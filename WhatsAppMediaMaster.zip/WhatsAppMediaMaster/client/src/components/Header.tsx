import React from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';

interface HeaderProps {
  title: string;
}

const Header: React.FC<HeaderProps> = ({ title }) => {
  const { connectionStatus } = useWhatsApp();
  
  return (
    <header className="bg-surface shadow-card h-16 flex items-center px-6">
      <h1 className="text-xl font-semibold text-neutral-dark">{title}</h1>
      <div className="ml-auto flex items-center space-x-4">
        {connectionStatus === 'connected' && (
          <div className="text-sm bg-success text-white px-3 py-1 rounded-full flex items-center">
            <i className="fas fa-check-circle mr-1"></i>
            <span>Connected</span>
          </div>
        )}
        
        {connectionStatus === 'connecting' && (
          <div className="text-sm bg-warning text-white px-3 py-1 rounded-full flex items-center">
            <i className="fas fa-circle-notch fa-spin mr-1"></i>
            <span>Connecting</span>
          </div>
        )}
        
        {connectionStatus === 'disconnected' && (
          <div className="text-sm bg-neutral-dark text-white px-3 py-1 rounded-full flex items-center">
            <i className="fas fa-times-circle mr-1"></i>
            <span>Disconnected</span>
          </div>
        )}
        
        {connectionStatus === 'error' && (
          <div className="text-sm bg-error text-white px-3 py-1 rounded-full flex items-center">
            <i className="fas fa-exclamation-circle mr-1"></i>
            <span>Error</span>
          </div>
        )}
        
        <button className="text-neutral-dark hover:text-primary focus:outline-none">
          <i className="fas fa-question-circle text-lg"></i>
        </button>
      </div>
    </header>
  );
};

export default Header;
