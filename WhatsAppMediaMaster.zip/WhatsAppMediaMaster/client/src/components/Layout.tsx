import React, { useState } from 'react';
import Sidebar from './Sidebar';
import Header from './Header';
import Footer from './Footer';
import { useLocation } from 'wouter';

interface LayoutProps {
  children: React.ReactNode;
}

export type TabRoute = {
  path: string;
  name: string;
  icon: string;
};

export const tabs: TabRoute[] = [
  { path: '/', name: 'Connection', icon: 'plug' },
  { path: '/download', name: 'Media Download', icon: 'download' },
  { path: '/messaging', name: 'Auto Messaging', icon: 'paper-plane' },
  { path: '/unread', name: 'Unread Messages', icon: 'envelope' },
  { path: '/history', name: 'Download History', icon: 'history' }
];

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [location] = useLocation();
  
  // Find the active tab name based on the current route
  const activeTab = tabs.find(tab => tab.path === location) || tabs[0];
  
  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar tabs={tabs} activeTab={activeTab} />
      
      <div className="flex-1 flex flex-col overflow-hidden bg-neutral">
        <Header title={activeTab.name} />
        
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
        
        <Footer />
      </div>
    </div>
  );
};

export default Layout;
