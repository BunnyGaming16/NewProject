import React from 'react';
import { Link } from 'wouter';
import { TabRoute } from './Layout';
import { useWhatsApp } from '@/context/WhatsAppContext';

interface SidebarProps {
  tabs: TabRoute[];
  activeTab: TabRoute;
}

const Sidebar: React.FC<SidebarProps> = ({ tabs, activeTab }) => {
  const { connectionStatus } = useWhatsApp();
  
  return (
    <div className="w-16 md:w-64 bg-primary text-white flex flex-col">
      {/* App Logo */}
      <div className="p-4 flex items-center justify-center md:justify-start">
        <i className="fas fa-comment-dots text-2xl md:mr-3"></i>
        <span className="hidden md:block text-lg font-semibold">WhatsApp Manager</span>
      </div>
      
      {/* Navigation Menu */}
      <nav className="flex-1 overflow-y-auto">
        <ul className="mt-6">
          {tabs.map((tab) => (
            <li key={tab.path} className="mb-1">
              <Link 
                href={tab.path}
                className={`flex items-center py-3 px-4 text-white ${
                  tab.path === activeTab.path 
                    ? 'bg-primary-dark' 
                    : 'opacity-80 hover:opacity-100 hover:bg-primary-dark'
                }`}
              >
                <i className={`fas fa-${tab.icon} w-6 text-center md:mr-3`}></i>
                <span className="hidden md:block">{tab.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
      
      {/* Settings & Account */}
      <div className="p-4 border-t border-primary-dark">
        <Link 
          href="#" 
          className="flex items-center text-white opacity-80 hover:opacity-100"
        >
          <i className="fas fa-cog w-6 text-center md:mr-3"></i>
          <span className="hidden md:block">Settings</span>
        </Link>
      </div>
    </div>
  );
};

export default Sidebar;
