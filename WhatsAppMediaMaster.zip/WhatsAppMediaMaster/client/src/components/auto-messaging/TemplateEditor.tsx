import React, { useState, useEffect } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';

const TemplateEditor: React.FC = () => {
  const { templates, selectedTemplateId, createTemplate, updateTemplate } = useWhatsApp();
  
  const [name, setName] = useState('');
  const [content, setContent] = useState('');
  const [schedulingEnabled, setSchedulingEnabled] = useState(false);
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [repeatSchedule, setRepeatSchedule] = useState('never');
  
  // Load template data when selected template changes
  useEffect(() => {
    if (selectedTemplateId) {
      const template = templates.find(t => t.id === selectedTemplateId);
      if (template) {
        setName(template.name);
        setContent(template.content);
      }
    } else {
      // New template
      setName('');
      setContent('');
    }
    
    // Reset scheduling
    setSchedulingEnabled(false);
    setScheduledDate('');
    setScheduledTime('');
    setRepeatSchedule('never');
  }, [selectedTemplateId, templates]);
  
  const handleSaveTemplate = async () => {
    if (!name || !content) {
      toast({
        title: "Validation error",
        description: "Template name and content are required",
        variant: "destructive"
      });
      return;
    }
    
    try {
      if (selectedTemplateId) {
        // Update existing template
        await updateTemplate(selectedTemplateId, { name, content });
        toast({
          title: "Template updated",
          description: "Your template has been updated successfully",
        });
      } else {
        // Create new template
        await createTemplate({ name, content });
        toast({
          title: "Template created",
          description: "Your new template has been created successfully",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save template",
        variant: "destructive"
      });
    }
  };
  
  const handleCancel = () => {
    if (selectedTemplateId) {
      // Reload the original template data
      const template = templates.find(t => t.id === selectedTemplateId);
      if (template) {
        setName(template.name);
        setContent(template.content);
      }
    } else {
      // Clear form
      setName('');
      setContent('');
    }
  };
  
  const insertVariable = (variable: string) => {
    setContent(prev => prev + ` ${variable}`);
  };
  
  return (
    <div className="fluent-card p-4">
      <h3 className="font-semibold mb-4">Edit Template</h3>
      
      <div className="mb-4">
        <Label className="block text-sm font-medium text-gray-700 mb-1">Template Name</Label>
        <Input 
          type="text" 
          value={name} 
          onChange={(e) => setName(e.target.value)}
          className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-1 focus:ring-primary"
        />
      </div>
      
      <div className="mb-4">
        <Label className="block text-sm font-medium text-gray-700 mb-1">Message Content</Label>
        <div className="border border-gray-300 rounded">
          {/* Simple Toolbar */}
          <div className="flex border-b border-gray-300 p-2 bg-gray-50">
            <button className="p-1 text-gray-700 hover:bg-gray-200 rounded mr-1">
              <i className="fas fa-bold"></i>
            </button>
            <button className="p-1 text-gray-700 hover:bg-gray-200 rounded mr-1">
              <i className="fas fa-italic"></i>
            </button>
            <button className="p-1 text-gray-700 hover:bg-gray-200 rounded mr-1">
              <i className="fas fa-link"></i>
            </button>
            <button className="p-1 text-gray-700 hover:bg-gray-200 rounded mr-1">
              <i className="fas fa-smile"></i>
            </button>
            <button className="ml-auto p-1 text-gray-700 hover:bg-gray-200 rounded">
              <i className="fas fa-paperclip"></i>
            </button>
          </div>
          {/* Editor */}
          <Textarea 
            className="w-full p-3 h-32 focus:outline-none" 
            placeholder="Enter your message here..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
          />
        </div>
      </div>
      
      <div className="mb-6">
        <Label className="block text-sm font-medium text-gray-700 mb-1">Insert Variable</Label>
        <div className="flex space-x-2 overflow-x-auto">
          <Button 
            variant="outline" 
            className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm py-1 px-2 rounded whitespace-nowrap"
            onClick={() => insertVariable('[Contact Name]')}
          >
            [Contact Name]
          </Button>
          <Button 
            variant="outline" 
            className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm py-1 px-2 rounded whitespace-nowrap"
            onClick={() => insertVariable('[Date]')}
          >
            [Date]
          </Button>
          <Button 
            variant="outline" 
            className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm py-1 px-2 rounded whitespace-nowrap"
            onClick={() => insertVariable('[Time]')}
          >
            [Time]
          </Button>
          <Button 
            variant="outline" 
            className="bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm py-1 px-2 rounded whitespace-nowrap"
            onClick={() => insertVariable('[Group Name]')}
          >
            [Group Name]
          </Button>
        </div>
      </div>
      
      <div className="border-t border-gray-200 pt-4 mb-4">
        <h4 className="font-medium mb-3">Message Scheduling</h4>
        
        <div className="mb-4">
          <div className="flex items-center space-x-2">
            <Switch
              checked={schedulingEnabled}
              onCheckedChange={setSchedulingEnabled}
              id="schedule-toggle"
            />
            <Label htmlFor="schedule-toggle" className="text-sm font-medium text-gray-700">
              Enable scheduling
            </Label>
          </div>
        </div>
        
        <div className={`grid grid-cols-2 gap-4 mb-4 ${!schedulingEnabled ? 'opacity-50' : ''}`}>
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-1">Date</Label>
            <Input 
              type="date" 
              className="w-full border border-gray-300 rounded px-3 py-2" 
              disabled={!schedulingEnabled}
              value={scheduledDate}
              onChange={(e) => setScheduledDate(e.target.value)}
            />
          </div>
          <div>
            <Label className="block text-sm font-medium text-gray-700 mb-1">Time</Label>
            <Input 
              type="time" 
              className="w-full border border-gray-300 rounded px-3 py-2" 
              disabled={!schedulingEnabled}
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
            />
          </div>
        </div>
        
        <div className={`mb-4 ${!schedulingEnabled ? 'opacity-50' : ''}`}>
          <Label className="block text-sm font-medium text-gray-700 mb-1">Repeat</Label>
          <Select
            value={repeatSchedule}
            onValueChange={setRepeatSchedule}
            disabled={!schedulingEnabled}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select repeat option" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="never">Never</SelectItem>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="flex space-x-2">
        <Button 
          className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-2 rounded"
          onClick={handleCancel}
        >
          Cancel
        </Button>
        <Button 
          className="flex-1 bg-primary hover:bg-primary-dark text-white py-2 rounded"
          onClick={handleSaveTemplate}
        >
          Save Template
        </Button>
      </div>
    </div>
  );
};

export default TemplateEditor;
