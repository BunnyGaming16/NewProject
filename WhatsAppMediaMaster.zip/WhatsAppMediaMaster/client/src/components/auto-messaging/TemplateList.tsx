import React, { useState } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';

const TemplateList: React.FC = () => {
  const { 
    templates, 
    selectedTemplateId, 
    setSelectedTemplateId, 
    deleteTemplate 
  } = useWhatsApp();
  
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredTemplates = templates.filter(template => 
    template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    template.content.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleDeleteTemplate = async (id: number) => {
    if (confirm('Are you sure you want to delete this template?')) {
      try {
        await deleteTemplate(id);
        toast({
          title: "Template deleted",
          description: "The template has been deleted successfully",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete template",
          variant: "destructive"
        });
      }
    }
  };
  
  const handleNewTemplate = () => {
    // Set selectedTemplateId to null to create a new template
    setSelectedTemplateId(null);
  };
  
  return (
    <div className="fluent-card p-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold">Message Templates</h3>
        <Button 
          className="text-white bg-primary hover:bg-primary-dark rounded px-3 py-1 text-sm"
          onClick={handleNewTemplate}
        >
          <i className="fas fa-plus mr-1"></i> New Template
        </Button>
      </div>
      
      <div className="mb-4">
        <Input 
          type="text" 
          placeholder="Search templates..." 
          className="w-full border border-gray-300 rounded px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      {/* Template List */}
      <div className="space-y-3 h-[calc(100vh-280px)] overflow-y-auto">
        {filteredTemplates.length > 0 ? (
          filteredTemplates.map((template) => (
            <div 
              key={template.id}
              className={`bg-white border ${
                selectedTemplateId === template.id ? 'border-primary' : 'border-gray-200 hover:border-primary'
              } rounded-md p-3 cursor-pointer transition-colors ${
                selectedTemplateId === template.id ? 'shadow-sm' : ''
              }`}
              onClick={() => setSelectedTemplateId(template.id)}
            >
              <div className="flex justify-between items-center mb-1">
                <h4 className="font-medium text-neutral-dark">{template.name}</h4>
                <div className="flex space-x-1">
                  <button 
                    className="text-gray-500 hover:text-primary"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedTemplateId(template.id);
                    }}
                  >
                    <i className="fas fa-pen text-xs"></i>
                  </button>
                  <button 
                    className="text-gray-500 hover:text-error"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteTemplate(template.id);
                    }}
                  >
                    <i className="fas fa-trash text-xs"></i>
                  </button>
                </div>
              </div>
              <p className="text-sm text-gray-600 line-clamp-2">{template.content}</p>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center h-40 text-gray-500">
            <i className="fas fa-file-alt text-4xl mb-2"></i>
            <p>No templates found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TemplateList;
