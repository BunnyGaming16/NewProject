import React, { useState } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { openDownloadFolder } from '@/lib/whatsapp';
import { toast } from '@/hooks/use-toast';

const HistoryTable: React.FC = () => {
  const { downloadHistory, chats, deleteDownloadRecord, refreshDownloadHistory } = useWhatsApp();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [timeFilter, setTimeFilter] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;
  
  // Apply filters
  const filteredDownloads = downloadHistory
    .filter(download => {
      // Search filter
      if (searchTerm) {
        const chat = chats.find(chat => chat.id === download.chatId);
        const chatName = chat?.name || '';
        
        return (
          chatName.toLowerCase().includes(searchTerm.toLowerCase()) ||
          download.path.toLowerCase().includes(searchTerm.toLowerCase())
        );
      }
      return true;
    })
    .filter(download => {
      // Time filter
      if (timeFilter === 'all') return true;
      
      const downloadDate = new Date(download.dateDownloaded);
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      
      switch (timeFilter) {
        case 'last7':
          const sevenDaysAgo = new Date(today);
          sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
          return downloadDate >= sevenDaysAgo;
          
        case 'last30':
          const thirtyDaysAgo = new Date(today);
          thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
          return downloadDate >= thirtyDaysAgo;
          
        case 'last90':
          const ninetyDaysAgo = new Date(today);
          ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
          return downloadDate >= ninetyDaysAgo;
          
        default:
          return true;
      }
    })
    .sort((a, b) => new Date(b.dateDownloaded).getTime() - new Date(a.dateDownloaded).getTime());
  
  // Pagination
  const totalPages = Math.ceil(filteredDownloads.length / itemsPerPage);
  const paginatedDownloads = filteredDownloads.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );
  
  const handleOpenFolder = (path: string) => {
    openDownloadFolder(path);
  };
  
  const handleDeleteRecord = async (id: number) => {
    if (confirm('Are you sure you want to delete this download record?')) {
      try {
        await deleteDownloadRecord(id);
        toast({
          title: "Record deleted",
          description: "The download record has been deleted successfully",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete the download record",
          variant: "destructive"
        });
      }
    }
  };
  
  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };
  
  // Format date
  const formatDate = (dateString: string | Date) => {
    const date = new Date(dateString);
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date >= today) {
      return `Today, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (date >= yesterday) {
      return `Yesterday, ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return date.toLocaleString([], {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      });
    }
  };
  
  return (
    <div className="bg-white border border-gray-200 rounded-md overflow-hidden mb-6">
      <div className="p-4 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
          <div className="relative">
            <Input 
              type="text" 
              placeholder="Search downloads..." 
              className="border border-gray-300 rounded px-3 py-1 text-sm w-full sm:w-48 pr-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <i className="fas fa-search absolute right-3 top-2 text-gray-400"></i>
          </div>
          <Select
            value={timeFilter}
            onValueChange={setTimeFilter}
          >
            <SelectTrigger className="border border-gray-300 rounded px-3 py-1 text-sm w-full sm:w-40">
              <SelectValue placeholder="Time filter" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="last7">Last 7 Days</SelectItem>
              <SelectItem value="last30">Last 30 Days</SelectItem>
              <SelectItem value="last90">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
          <Button 
            variant="outline" 
            className="text-primary border-primary hover:bg-primary/10"
            onClick={refreshDownloadHistory}
          >
            <i className="fas fa-sync-alt mr-1"></i> Refresh
          </Button>
        </div>
      </div>
      
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[180px]">Download Date</TableHead>
            <TableHead>Source</TableHead>
            <TableHead>Files</TableHead>
            <TableHead>Size</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {paginatedDownloads.length > 0 ? (
            paginatedDownloads.map((download) => {
              const chat = chats.find(chat => chat.id === download.chatId);
              const fileTypes = download.fileTypes as Record<string, number>;
              
              // Find the most common file type
              let primaryFileType = 'document';
              let maxCount = 0;
              
              for (const [type, count] of Object.entries(fileTypes)) {
                if (count > maxCount) {
                  maxCount = count;
                  primaryFileType = type;
                }
              }
              
              return (
                <TableRow key={download.id}>
                  <TableCell className="font-medium">
                    {formatDate(download.dateDownloaded)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 mr-2">
                        {chat?.type === 'group' ? (
                          <i className="fas fa-users text-xs"></i>
                        ) : (
                          <i className="fas fa-user text-xs"></i>
                        )}
                      </div>
                      <div className="text-sm">{chat?.name || 'Unknown'}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <i className={`fas fa-${
                        primaryFileType === 'image' ? 'images' :
                        primaryFileType === 'video' ? 'video' :
                        primaryFileType === 'audio' ? 'headphones' : 'file-alt'
                      } text-primary mr-2`}></i>
                      <span className="text-sm">
                        {download.fileCount} file{download.fileCount !== 1 ? 's' : ''}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{formatFileSize(download.totalSize)}</div>
                  </TableCell>
                  <TableCell>
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                      {download.status.charAt(0).toUpperCase() + download.status.slice(1)}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-primary hover:text-primary-dark h-8 w-8 p-0 mr-1"
                      onClick={() => handleOpenFolder(download.path)}
                    >
                      <i className="fas fa-folder-open"></i>
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-gray-500 hover:text-error h-8 w-8 p-0"
                      onClick={() => handleDeleteRecord(download.id)}
                    >
                      <i className="fas fa-trash"></i>
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })
          ) : (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-8">
                <div className="flex flex-col items-center text-gray-500">
                  <i className="fas fa-inbox text-4xl mb-2"></i>
                  <p>No download history found</p>
                </div>
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
      
      {/* Pagination */}
      {totalPages > 1 && (
        <div className="p-4 border-t border-gray-200 flex items-center justify-between">
          <div className="text-sm text-gray-700">
            Showing <span className="font-medium">{(currentPage - 1) * itemsPerPage + 1}</span> to{' '}
            <span className="font-medium">
              {Math.min(currentPage * itemsPerPage, filteredDownloads.length)}
            </span>{' '}
            of <span className="font-medium">{filteredDownloads.length}</span> results
          </div>
          <div className="flex space-x-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              Previous
            </Button>
            {Array.from({ length: Math.min(totalPages, 3) }, (_, i) => {
              let pageNumber = currentPage;
              if (totalPages <= 3) {
                pageNumber = i + 1;
              } else if (currentPage === 1) {
                pageNumber = i + 1;
              } else if (currentPage === totalPages) {
                pageNumber = totalPages - 2 + i;
              } else {
                pageNumber = currentPage - 1 + i;
              }
              
              return (
                <Button
                  key={pageNumber}
                  variant={currentPage === pageNumber ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(pageNumber)}
                >
                  {pageNumber}
                </Button>
              );
            })}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Next
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default HistoryTable;
