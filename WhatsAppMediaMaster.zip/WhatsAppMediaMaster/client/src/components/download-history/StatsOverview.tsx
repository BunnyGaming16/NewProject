import React from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';

const StatsOverview: React.FC = () => {
  const { downloadHistory } = useWhatsApp();
  
  // Calculate stats
  const totalDownloads = downloadHistory.length;
  
  let totalSize = 0;
  let downloadsThisMonth = 0;
  
  // Track unique file types
  const fileTypes = new Set<string>();
  
  // Current date for this month calculation
  const now = new Date();
  const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  
  downloadHistory.forEach(download => {
    // Add to total size
    totalSize += download.totalSize;
    
    // Count downloads this month
    if (new Date(download.dateDownloaded) >= firstDayOfMonth) {
      downloadsThisMonth++;
    }
    
    // Add file types
    const types = download.fileTypes as Record<string, number>;
    Object.keys(types).forEach(type => {
      if (types[type] > 0) {
        fileTypes.add(type);
      }
    });
  });
  
  // Format size in GB with one decimal place
  const formatSize = (bytes: number) => {
    const gb = bytes / (1024 * 1024 * 1024);
    return gb.toFixed(1);
  };
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <div className="bg-white border border-gray-200 rounded-md p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Total Downloads</p>
            <p className="text-2xl font-semibold">{totalDownloads}</p>
          </div>
          <div className="bg-primary bg-opacity-10 p-3 rounded-full">
            <i className="fas fa-cloud-download-alt text-primary"></i>
          </div>
        </div>
      </div>
      
      <div className="bg-white border border-gray-200 rounded-md p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">Storage Used</p>
            <p className="text-2xl font-semibold">{formatSize(totalSize)} GB</p>
          </div>
          <div className="bg-purple-100 p-3 rounded-full">
            <i className="fas fa-database text-purple-700"></i>
          </div>
        </div>
      </div>
      
      <div className="bg-white border border-gray-200 rounded-md p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">This Month</p>
            <p className="text-2xl font-semibold">{downloadsThisMonth}</p>
          </div>
          <div className="bg-green-100 p-3 rounded-full">
            <i className="fas fa-calendar-alt text-green-700"></i>
          </div>
        </div>
      </div>
      
      <div className="bg-white border border-gray-200 rounded-md p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-500">File Types</p>
            <p className="text-2xl font-semibold">{fileTypes.size}</p>
          </div>
          <div className="bg-amber-100 p-3 rounded-full">
            <i className="fas fa-file-alt text-amber-700"></i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatsOverview;
