import React, { useState } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

const ChatList: React.FC = () => {
  const { 
    chats, 
    selectedChatIds, 
    toggleChatSelection, 
    selectAllChats, 
    chatFilter, 
    setChatFilter,
    refreshChats
  } = useWhatsApp();
  
  const [searchTerm, setSearchTerm] = useState('');
  
  // Filter chats based on the chat type filter and search term
  const filteredChats = chats
    .filter(chat => {
      if (chatFilter === 'all') return true;
      return chat.type === (chatFilter === 'groups' ? 'group' : 'contact');
    })
    .filter(chat => {
      if (!searchTerm) return true;
      return chat.name.toLowerCase().includes(searchTerm.toLowerCase());
    });
  
  return (
    <div className="fluent-card p-4 h-[calc(100vh-140px)] flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold">Select Chats</h3>
        <div className="flex items-center">
          <button 
            className="text-primary hover:text-primary-dark focus:outline-none mr-2"
            onClick={refreshChats}
          >
            <i className="fas fa-sync-alt"></i>
          </button>
          <Input 
            type="text" 
            placeholder="Search chats..." 
            className="border border-gray-300 rounded px-3 py-1 text-sm w-32 focus:outline-none focus:ring-1 focus:ring-primary"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      <div className="flex mb-4">
        <button 
          className={`${
            chatFilter === 'all' 
              ? 'bg-primary text-white' 
              : 'bg-white text-neutral-dark border-t border-b border-r border-gray-300'
          } rounded-l px-3 py-1 text-sm`}
          onClick={() => setChatFilter('all')}
        >
          All
        </button>
        <button 
          className={`${
            chatFilter === 'groups' 
              ? 'bg-primary text-white' 
              : 'bg-white text-neutral-dark border-t border-b border-r border-gray-300'
          } px-3 py-1 text-sm`}
          onClick={() => setChatFilter('groups')}
        >
          Groups
        </button>
        <button 
          className={`${
            chatFilter === 'contacts'
              ? 'bg-primary text-white' 
              : 'bg-white text-neutral-dark border-t border-b border-r border-gray-300'
          } rounded-r px-3 py-1 text-sm`}
          onClick={() => setChatFilter('contacts')}
        >
          Contacts
        </button>
      </div>
      
      {/* Chat List */}
      <div className="overflow-y-auto flex-1">
        {filteredChats.length > 0 ? (
          filteredChats.map((chat) => (
            <div 
              key={chat.id}
              className={`flex items-center p-3 hover:bg-neutral rounded cursor-pointer mb-1 ${
                selectedChatIds.includes(chat.id) ? 'bg-blue-50 border-l-4 border-primary' : ''
              }`}
              onClick={() => toggleChatSelection(chat.id)}
            >
              <div className="relative flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-gray-300 flex items-center justify-center text-gray-600">
                  {chat.type === 'group' ? (
                    <i className="fas fa-users"></i>
                  ) : (
                    <i className="fas fa-user"></i>
                  )}
                </div>
                {chat.unreadCount > 0 && (
                  <span className="absolute bottom-0 right-0 w-3 h-3 bg-success rounded-full border-2 border-white"></span>
                )}
              </div>
              <div className="ml-3 flex-1">
                <div className="flex justify-between">
                  <span className="font-medium text-neutral-dark">{chat.name}</span>
                  <span className="text-xs text-gray-500">
                    {chat.lastUpdated ? new Date(chat.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500 truncate w-36">{chat.lastMessage}</span>
                  {chat.unreadCount > 0 && (
                    <span className="bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {chat.unreadCount}
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <i className="fas fa-comment-slash text-4xl mb-2"></i>
            <p>No chats found</p>
          </div>
        )}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200">
        <Button 
          className="w-full bg-primary hover:bg-primary-dark text-white rounded py-2 flex items-center justify-center"
          onClick={selectAllChats}
        >
          <i className="fas fa-check-square mr-2"></i> Select All
        </Button>
      </div>
    </div>
  );
};

export default ChatList;
