import React, { useState } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/hooks/use-toast';
import { selectDownloadFolder } from '@/lib/whatsapp';

const DownloadOptions: React.FC = () => {
  const {
    selectedFileTypes,
    toggleFileType,
    timeFilter,
    setTimeFilter,
    senderFilter,
    setSenderFilter,
    customDateRange,
    setCustomDateRange,
    downloadPath,
    setDownloadPath,
    sendAutoMessage,
    setSendAutoMessage,
    downloadMedia,
    templates,
    selectedTemplateId,
    setSelectedTemplateId
  } = useWhatsApp();
  
  const [showCustomDateRange, setShowCustomDateRange] = useState(timeFilter === 'custom');
  
  const handleTimeFilterChange = (value: string) => {
    setTimeFilter(value as any);
    setShowCustomDateRange(value === 'custom');
  };
  
  const handleBrowseForFolder = async () => {
    const folderPath = await selectDownloadFolder();
    if (folderPath) {
      setDownloadPath(folderPath);
    }
  };
  
  const handleStartDownload = async () => {
    if (selectedFileTypes.length === 0) {
      toast({
        title: "Selection required",
        description: "Please select at least one file type to download",
        variant: "destructive"
      });
      return;
    }
    
    const result = await downloadMedia();
    
    if (result.success) {
      toast({
        title: "Download started",
        description: "Your files will be downloaded in the background",
      });
    } else {
      toast({
        title: "Download failed",
        description: result.error || "An error occurred while starting the download",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="fluent-card p-4">
      <h3 className="font-semibold mb-4">Download Options</h3>
      
      {/* File Type Filters */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-gray-700 mb-2">File Types</Label>
        <div className="grid grid-cols-2 gap-2">
          <Label className="flex items-center bg-white p-3 border border-gray-300 rounded cursor-pointer hover:bg-neutral">
            <Checkbox 
              checked={selectedFileTypes.includes('image')}
              onCheckedChange={() => toggleFileType('image')}
              className="form-checkbox h-4 w-4 text-primary rounded"
            />
            <span className="ml-2 text-sm"><i className="far fa-image text-primary mr-1"></i> Images</span>
          </Label>
          <Label className="flex items-center bg-white p-3 border border-gray-300 rounded cursor-pointer hover:bg-neutral">
            <Checkbox 
              checked={selectedFileTypes.includes('video')}
              onCheckedChange={() => toggleFileType('video')}
              className="form-checkbox h-4 w-4 text-primary rounded"
            />
            <span className="ml-2 text-sm"><i className="fas fa-video text-primary mr-1"></i> Videos</span>
          </Label>
          <Label className="flex items-center bg-white p-3 border border-gray-300 rounded cursor-pointer hover:bg-neutral">
            <Checkbox 
              checked={selectedFileTypes.includes('audio')}
              onCheckedChange={() => toggleFileType('audio')}
              className="form-checkbox h-4 w-4 text-primary rounded"
            />
            <span className="ml-2 text-sm"><i className="fas fa-file-audio text-primary mr-1"></i> Audio</span>
          </Label>
          <Label className="flex items-center bg-white p-3 border border-gray-300 rounded cursor-pointer hover:bg-neutral">
            <Checkbox 
              checked={selectedFileTypes.includes('document')}
              onCheckedChange={() => toggleFileType('document')}
              className="form-checkbox h-4 w-4 text-primary rounded"
            />
            <span className="ml-2 text-sm"><i className="fas fa-file-alt text-primary mr-1"></i> Documents</span>
          </Label>
        </div>
      </div>
      
      {/* Time Period Filter */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-gray-700 mb-2">Time Period</Label>
        <div className="relative">
          <Select
            value={timeFilter}
            onValueChange={handleTimeFilterChange}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select time period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="yesterday">Yesterday</SelectItem>
              <SelectItem value="last7days">Last 7 Days</SelectItem>
              <SelectItem value="last30days">Last 30 Days</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Custom Date Range */}
      {showCustomDateRange && (
        <div className="mb-6">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-1">From</Label>
              <Input 
                type="date" 
                className="w-full border border-gray-300 rounded-md p-2"
                value={customDateRange.from || ''}
                onChange={(e) => setCustomDateRange({...customDateRange, from: e.target.value})}
              />
            </div>
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-1">To</Label>
              <Input 
                type="date" 
                className="w-full border border-gray-300 rounded-md p-2"
                value={customDateRange.to || ''}
                onChange={(e) => setCustomDateRange({...customDateRange, to: e.target.value})}
              />
            </div>
          </div>
        </div>
      )}
      
      {/* Sender Filter */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-gray-700 mb-2">Sender Options</Label>
        <RadioGroup 
          value={senderFilter}
          onValueChange={(value) => setSenderFilter(value as any)}
          className="space-y-2"
        >
          <Label className="flex items-center bg-white p-3 border border-gray-300 rounded cursor-pointer hover:bg-neutral">
            <RadioGroupItem value="all" id="sender-all" />
            <span className="ml-2 text-sm">All Messages</span>
          </Label>
          <Label className="flex items-center bg-white p-3 border border-gray-300 rounded cursor-pointer hover:bg-neutral">
            <RadioGroupItem value="excludeOwn" id="sender-exclude" />
            <span className="ml-2 text-sm">Exclude My Media</span>
          </Label>
          <Label className="flex items-center bg-white p-3 border border-gray-300 rounded cursor-pointer hover:bg-neutral">
            <RadioGroupItem value="onlyOwn" id="sender-only" />
            <span className="ml-2 text-sm">Only My Media</span>
          </Label>
        </RadioGroup>
      </div>
      
      {/* Download Path */}
      <div className="mb-6">
        <Label className="block text-sm font-medium text-gray-700 mb-2">Download Location</Label>
        <div className="flex">
          <Input 
            type="text" 
            value={downloadPath}
            onChange={(e) => setDownloadPath(e.target.value)}
            className="flex-1 border border-gray-300 rounded-l-md p-2 bg-gray-50" 
            readOnly
          />
          <Button 
            className="bg-gray-200 hover:bg-gray-300 text-gray-700 px-4 rounded-r-md border-t border-r border-b border-gray-300"
            onClick={handleBrowseForFolder}
          >
            <i className="fas fa-folder-open"></i>
          </Button>
        </div>
      </div>
      
      {/* Auto-messaging Toggle */}
      <div className="mb-6">
        <div className="flex items-center space-x-2">
          <Switch
            checked={sendAutoMessage}
            onCheckedChange={setSendAutoMessage}
            id="auto-message-toggle"
          />
          <Label htmlFor="auto-message-toggle" className="text-sm font-medium text-gray-700">
            Send auto-message after download
          </Label>
        </div>
        
        {sendAutoMessage && (
          <div className="mt-3">
            <Label className="block text-sm font-medium text-gray-700 mb-1">Template</Label>
            <Select
              value={selectedTemplateId?.toString() || ''}
              onValueChange={(value) => setSelectedTemplateId(parseInt(value))}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a template" />
              </SelectTrigger>
              <SelectContent>
                {templates.map((template) => (
                  <SelectItem key={template.id} value={template.id.toString()}>
                    {template.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
      
      {/* Download Button */}
      <div>
        <Button 
          className="w-full bg-accent hover:bg-accent/90 text-white font-semibold py-3 px-4 rounded flex items-center justify-center"
          onClick={handleStartDownload}
        >
          <i className="fas fa-cloud-download-alt mr-2"></i> Start Download
        </Button>
      </div>
    </div>
  );
};

export default DownloadOptions;
