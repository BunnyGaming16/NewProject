import React from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { openDownloadFolder } from '@/lib/whatsapp';

const DownloadStatus: React.FC = () => {
  const { 
    selectedChatIds, 
    downloadProgress, 
    chats, 
    downloadPath 
  } = useWhatsApp();
  
  const selectedChats = chats.filter(chat => selectedChatIds.includes(chat.id));
  const totalFilesDetected = 143; // This would be dynamic in a real implementation
  
  const handleOpenFolder = () => {
    openDownloadFolder(downloadPath);
  };
  
  const progressPercentage = downloadProgress.totalFiles > 0
    ? (downloadProgress.filesProcessed / downloadProgress.totalFiles) * 100
    : 0;
  
  return (
    <div className="fluent-card p-4 h-[calc(100vh-140px)] flex flex-col">
      <h3 className="font-semibold mb-4">Download Status</h3>
      
      {/* Status Overview */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-blue-50 border border-blue-100 rounded-md p-3 text-center">
          <div className="text-primary text-2xl font-bold">{selectedChats.length}</div>
          <div className="text-xs text-gray-600">Chats Selected</div>
        </div>
        <div className="bg-green-50 border border-green-100 rounded-md p-3 text-center">
          <div className="text-success text-2xl font-bold">{downloadProgress.filesProcessed}</div>
          <div className="text-xs text-gray-600">Files Downloaded</div>
        </div>
        <div className="bg-purple-50 border border-purple-100 rounded-md p-3 text-center">
          <div className="text-purple-700 text-2xl font-bold">{totalFilesDetected}</div>
          <div className="text-xs text-gray-600">Files Detected</div>
        </div>
        <div className="bg-gray-50 border border-gray-200 rounded-md p-3 text-center">
          <div className="text-gray-700 text-2xl font-bold">
            {downloadProgress.totalFiles > 0 
              ? `${Math.round(progressPercentage)}%` 
              : '0%'
            }
          </div>
          <div className="text-xs text-gray-600">Progress</div>
        </div>
      </div>
      
      {/* Download Progress */}
      <div className="mb-6">
        <div className="flex justify-between text-sm mb-1">
          <span>Overall Progress</span>
          <span>
            {downloadProgress.filesProcessed}/{downloadProgress.totalFiles || totalFilesDetected} files
          </span>
        </div>
        <Progress value={progressPercentage} className="h-4" />
      </div>
      
      {/* File Preview */}
      <div className="flex-1 overflow-y-auto">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Media Preview</h4>
        {downloadProgress.inProgress ? (
          <div className="bg-white border border-gray-200 rounded-md p-4">
            <div className="flex items-center space-x-3">
              <i className="fas fa-spinner fa-spin text-primary text-xl"></i>
              <div>
                <div className="text-sm font-medium">Downloading...</div>
                {downloadProgress.currentFile && (
                  <div className="text-xs text-gray-500">{downloadProgress.currentFile}</div>
                )}
              </div>
            </div>
          </div>
        ) : downloadProgress.filesProcessed > 0 ? (
          <div className="grid grid-cols-3 gap-2">
            {/* This would be populated with actual downloaded files in a real implementation */}
            <div className="bg-white border border-gray-200 rounded-md overflow-hidden">
              <div className="h-20 bg-gray-100 flex items-center justify-center">
                <i className="far fa-image text-gray-400 text-xl"></i>
              </div>
              <div className="p-2">
                <div className="text-xs truncate">image_001.jpg</div>
                <div className="text-xs text-gray-500">234 KB</div>
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-gray-50 border border-gray-200 rounded-md p-6 text-center h-48 flex flex-col items-center justify-center">
            <i className="far fa-images text-4xl text-gray-400 mb-2"></i>
            <p className="text-gray-500 text-sm">Start download to see media files</p>
          </div>
        )}
      </div>
      
      {/* Action Buttons */}
      <div className="flex space-x-2 mt-4 border-t border-gray-200 pt-4">
        <Button 
          className="flex-1 bg-neutral-dark hover:bg-neutral-dark/90 text-white rounded py-2 flex items-center justify-center"
          disabled={!downloadProgress.inProgress}
        >
          <i className="fas fa-pause mr-1"></i> Pause
        </Button>
        <Button 
          className="flex-1 bg-error hover:bg-error/90 text-white rounded py-2 flex items-center justify-center"
          disabled={!downloadProgress.inProgress}
        >
          <i className="fas fa-stop mr-1"></i> Cancel
        </Button>
        <Button 
          className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded py-2 flex items-center justify-center"
          onClick={handleOpenFolder}
        >
          <i className="fas fa-folder-open mr-1"></i> Open
        </Button>
      </div>
    </div>
  );
};

export default DownloadStatus;
