import React, { useState, useEffect } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from '@/hooks/use-toast';

const ConversationHistory: React.FC = () => {
  const { unreadMessages, chats, sendMessage } = useWhatsApp();
  
  const [selectedChatId, setSelectedChatId] = useState<number | null>(null);
  const [messageContent, setMessageContent] = useState('');
  
  // When an unread message is selected from another component,
  // update the selected chat
  useEffect(() => {
    if (unreadMessages.length > 0) {
      // Get the first unread message's chat id
      const chatId = unreadMessages[0].chatId;
      setSelectedChatId(chatId);
    }
  }, [unreadMessages]);
  
  // Get the selected chat
  const selectedChat = chats.find(chat => chat.id === selectedChatId);
  
  // Get messages for the selected chat
  // This is a placeholder, as we don't have actual chat history
  // We'll display the unread messages for this chat
  const chatMessages = unreadMessages.filter(message => message.chatId === selectedChatId);
  
  const handleSendMessage = async () => {
    if (!selectedChatId || !messageContent.trim()) return;
    
    try {
      const result = await sendMessage(selectedChatId, messageContent);
      
      if (result.success) {
        setMessageContent('');
        toast({
          title: "Message sent",
          description: "Your message was sent successfully",
        });
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to send message",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive"
      });
    }
  };
  
  return (
    <div className="fluent-card p-4 h-[calc(100vh-140px)] flex flex-col">
      <h3 className="font-semibold mb-4">Conversation History</h3>
      
      {/* Message Thread */}
      <ScrollArea className="flex-1 overflow-y-auto space-y-4 mb-4">
        {selectedChat ? (
          chatMessages.length > 0 ? (
            chatMessages.map((message) => (
              <div key={message.id} className="flex items-start mb-4">
                <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 mr-2 mt-1">
                  {message.sender === 'You' ? (
                    <i className="fas fa-user"></i>
                  ) : (
                    selectedChat.type === 'group' ? (
                      <i className="fas fa-users"></i>
                    ) : (
                      <i className="fas fa-user"></i>
                    )
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex justify-between">
                    <span className="font-medium text-sm">
                      {message.sender || (selectedChat.type === 'group' ? 'Group Member' : selectedChat.name)}
                    </span>
                    <span className="text-xs text-gray-500">
                      {new Date(message.timestamp).toLocaleString([], {
                        weekday: 'short',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3 mt-1">
                    <p className="text-sm">{message.content}</p>
                    {message.hasMedia && (
                      <div className="mt-2 text-xs text-gray-500">
                        <i className={`fas fa-${
                          message.mediaType === 'image' ? 'image' :
                          message.mediaType === 'video' ? 'video' :
                          message.mediaType === 'audio' ? 'headphones' : 'file'
                        } mr-1`}></i>
                        {message.mediaType} attached
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center h-40 text-gray-500">
              <i className="fas fa-comments text-4xl mb-2"></i>
              <p>No messages to display</p>
              <p className="text-sm mt-1">Select a chat with unread messages</p>
            </div>
          )
        ) : (
          <div className="flex flex-col items-center justify-center h-40 text-gray-500">
            <i className="fas fa-comment-slash text-4xl mb-2"></i>
            <p>No conversation selected</p>
          </div>
        )}
      </ScrollArea>
      
      <div className="mt-4 pt-4 border-t border-gray-200">
        <div className="flex">
          <Input 
            type="text" 
            placeholder={selectedChat ? "Type a message..." : "Select a conversation first"}
            className="flex-1 border border-gray-300 rounded-l-md px-3 py-2"
            value={messageContent}
            onChange={(e) => setMessageContent(e.target.value)}
            disabled={!selectedChat}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
          />
          <Button 
            className="bg-primary hover:bg-primary-dark text-white px-4 py-2 rounded-r-md"
            onClick={handleSendMessage}
            disabled={!selectedChat || !messageContent.trim()}
          >
            <i className="fas fa-paper-plane"></i>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ConversationHistory;
