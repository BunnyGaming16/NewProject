import React, { useState, useEffect } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { toast } from '@/hooks/use-toast';

const ResponseOptions: React.FC = () => {
  const { 
    templates, 
    chats, 
    unreadMessages, 
    sendMessage, 
    markMessageAsRead
  } = useWhatsApp();
  
  const [selectedMessageId, setSelectedMessageId] = useState<number | null>(null);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  const [messageContent, setMessageContent] = useState('');
  
  // Find the selected message and its corresponding chat
  const selectedMessage = unreadMessages.find(message => message.id === selectedMessageId);
  const selectedChat = selectedMessage ? chats.find(chat => chat.id === selectedMessage.chatId) : null;
  
  // When a template is selected, load its content
  useEffect(() => {
    if (selectedTemplateId) {
      const template = templates.find(t => t.id.toString() === selectedTemplateId);
      if (template) {
        setMessageContent(template.content);
      }
    }
  }, [selectedTemplateId, templates]);
  
  // When a different message is selected, reset the template selection
  useEffect(() => {
    setSelectedTemplateId('');
    setMessageContent('');
  }, [selectedMessageId]);
  
  const handleSendResponse = async () => {
    if (!selectedChat || !messageContent) {
      toast({
        title: "Error",
        description: "Please select a message and enter response content",
        variant: "destructive"
      });
      return;
    }
    
    try {
      const result = await sendMessage(selectedChat.id, messageContent);
      
      if (result.success) {
        toast({
          title: "Success",
          description: "Response sent successfully",
        });
        
        // Mark the message as read
        if (selectedMessageId) {
          await markMessageAsRead(selectedMessageId);
        }
        
        // Reset the form
        setMessageContent('');
        setSelectedTemplateId('');
      } else {
        toast({
          title: "Error",
          description: result.error || "Failed to send response",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send response",
        variant: "destructive"
      });
    }
  };
  
  const handleMarkAsRead = async () => {
    if (selectedMessageId) {
      try {
        await markMessageAsRead(selectedMessageId);
        toast({
          title: "Success",
          description: "Message marked as read",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to mark message as read",
          variant: "destructive"
        });
      }
    }
  };
  
  return (
    <div className="fluent-card p-4">
      <h3 className="font-semibold mb-4">Quick Response</h3>
      
      <div className="mb-4">
        <Label className="block text-sm font-medium text-gray-700 mb-1">Selected Conversation</Label>
        <div className={`border rounded-md p-3 ${selectedChat ? 'bg-blue-50 border-blue-100' : 'bg-gray-50 border-gray-200'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 mr-2">
                {selectedChat?.type === 'group' ? (
                  <i className="fas fa-users"></i>
                ) : (
                  <i className="fas fa-user"></i>
                )}
              </div>
              <span className="font-medium">
                {selectedChat?.name || 'Select a conversation'}
              </span>
            </div>
            {selectedMessage && (
              <span className="text-xs text-gray-500">New message</span>
            )}
          </div>
        </div>
      </div>
      
      <div className="mb-4">
        <Label className="block text-sm font-medium text-gray-700 mb-1">Choose Response Template</Label>
        <Select
          value={selectedTemplateId}
          onValueChange={setSelectedTemplateId}
          disabled={!selectedChat}
        >
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select a template" />
          </SelectTrigger>
          <SelectContent>
            {templates.map((template) => (
              <SelectItem key={template.id} value={template.id.toString()}>
                {template.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {selectedTemplateId && (
        <div className="mb-4">
          <Label className="block text-sm font-medium text-gray-700 mb-1">Message Preview</Label>
          <div className="border border-gray-300 rounded p-3 bg-gray-50">
            <p className="text-sm">{messageContent}</p>
          </div>
        </div>
      )}
      
      <div className="mb-4">
        <Label className="block text-sm font-medium text-gray-700 mb-1">Customize Message</Label>
        <Textarea 
          className="w-full border border-gray-300 rounded px-3 py-2 h-20"
          value={messageContent}
          onChange={(e) => setMessageContent(e.target.value)}
          disabled={!selectedChat}
          placeholder={selectedChat ? "Type your response here..." : "Select a conversation first"}
        />
      </div>
      
      <div className="flex space-x-2">
        <Button 
          className="flex-1 bg-primary hover:bg-primary-dark text-white py-2 rounded flex items-center justify-center"
          onClick={handleSendResponse}
          disabled={!selectedChat || !messageContent}
        >
          <i className="fas fa-paper-plane mr-2"></i> Send Response
        </Button>
        <Button 
          className="flex-1 bg-success hover:bg-success/90 text-white py-2 rounded flex items-center justify-center"
          onClick={handleMarkAsRead}
          disabled={!selectedMessageId}
        >
          <i className="fas fa-check mr-2"></i> Mark as Read
        </Button>
      </div>
    </div>
  );
};

export default ResponseOptions;
