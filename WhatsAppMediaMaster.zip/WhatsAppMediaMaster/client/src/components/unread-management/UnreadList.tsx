import React, { useState } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

const UnreadList: React.FC = () => {
  const { 
    unreadMessages, 
    chats, 
    markMessageAsRead, 
    markAllMessagesAsRead,
    refreshMessages,
    selectedTemplateId,
    setSelectedTemplateId
  } = useWhatsApp();
  
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMessageId, setSelectedMessageId] = useState<number | null>(null);
  
  // Filter messages based on search term
  const filteredMessages = unreadMessages.filter(message => {
    if (!searchTerm) return true;
    
    const chat = chats.find(chat => chat.id === message.chatId);
    return (
      message.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (chat && chat.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      message.sender.toLowerCase().includes(searchTerm.toLowerCase())
    );
  });
  
  const handleMarkAllAsRead = async () => {
    try {
      // For each chat with unread messages
      const chatIds = [...new Set(unreadMessages.map(message => message.chatId))];
      
      for (const chatId of chatIds) {
        await markAllMessagesAsRead(chatId);
      }
      
      toast({
        title: "Success",
        description: "All messages marked as read",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to mark messages as read",
        variant: "destructive"
      });
    }
  };
  
  const handleRefresh = () => {
    refreshMessages();
  };
  
  return (
    <div className="fluent-card p-4 h-[calc(100vh-140px)] flex flex-col">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-semibold">Unread Messages</h3>
        <button 
          className="text-primary hover:text-primary-dark"
          onClick={handleRefresh}
        >
          <i className="fas fa-sync-alt"></i>
        </button>
      </div>
      
      <div className="mb-4">
        <Input 
          type="text" 
          placeholder="Search messages..." 
          className="w-full border border-gray-300 rounded px-3 py-2 text-sm"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>
      
      {/* Message List */}
      <div className="overflow-y-auto flex-1">
        {filteredMessages.length > 0 ? (
          filteredMessages.map((message) => {
            const chat = chats.find(chat => chat.id === message.chatId);
            
            return (
              <div 
                key={message.id}
                className={`border-b border-gray-200 last:border-b-0 hover:bg-gray-50 p-3 cursor-pointer transition-colors ${
                  selectedMessageId === message.id ? 'bg-blue-50' : ''
                }`}
                onClick={() => setSelectedMessageId(message.id)}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center text-gray-600 mr-2">
                      {chat?.type === 'group' ? (
                        <i className="fas fa-users"></i>
                      ) : (
                        <i className="fas fa-user"></i>
                      )}
                    </div>
                    <span className="font-medium text-neutral-dark">
                      {chat?.name || 'Unknown'}
                    </span>
                  </div>
                  <span className="text-xs text-gray-500">
                    {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <p className="text-sm text-gray-700 mb-1">
                  {message.sender && `${message.sender}: `}{message.content}
                </p>
                <div className="flex justify-between items-center">
                  <div className="flex space-x-1">
                    <Badge className="bg-gray-100 text-gray-700 text-xs py-0.5 px-2 rounded">
                      {chat?.type === 'group' ? 'Group' : 'Contact'}
                    </Badge>
                    <Badge className="bg-primary bg-opacity-10 text-primary text-xs py-0.5 px-2 rounded">
                      New
                    </Badge>
                  </div>
                  <div className="flex space-x-1">
                    <button 
                      className="text-gray-500 hover:text-primary"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedMessageId(message.id);
                      }}
                    >
                      <i className="fas fa-reply text-xs"></i>
                    </button>
                    <button 
                      className="text-gray-500 hover:text-success"
                      onClick={(e) => {
                        e.stopPropagation();
                        markMessageAsRead(message.id);
                      }}
                    >
                      <i className="fas fa-check text-xs"></i>
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="flex flex-col items-center justify-center h-40 text-gray-500">
            <i className="fas fa-envelope-open text-4xl mb-2"></i>
            <p>No unread messages</p>
          </div>
        )}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200">
        <Button 
          className="w-full bg-success hover:bg-success/90 text-white rounded py-2 flex items-center justify-center"
          onClick={handleMarkAllAsRead}
          disabled={unreadMessages.length === 0}
        >
          <i className="fas fa-check-double mr-2"></i> Mark All as Read
        </Button>
      </div>
    </div>
  );
};

export default UnreadList;
