import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { 
  Chat, 
  Template, 
  Download, 
  Message, 
  Settings,
  FileType,
  TimeFilter,
  SenderFilter,
  ConnectionStatus
} from '@shared/schema';

interface WhatsAppContextType {
  // Connection state
  connectionStatus: ConnectionStatus;
  qrCode: string | null;
  connect: () => Promise<void>;
  disconnect: () => Promise<void>;
  refreshQRCode: () => Promise<void>;
  
  // Chats
  chats: Chat[];
  selectedChatIds: number[];
  toggleChatSelection: (chatId: number) => void;
  selectAllChats: () => void;
  unselectAllChats: () => void;
  refreshChats: () => Promise<void>;
  chatFilter: 'all' | 'groups' | 'contacts';
  setChatFilter: (filter: 'all' | 'groups' | 'contacts') => void;
  
  // Media Download
  selectedFileTypes: FileType[];
  toggleFileType: (type: FileType) => void;
  timeFilter: TimeFilter;
  setTimeFilter: (filter: TimeFilter) => void;
  senderFilter: SenderFilter;
  setSenderFilter: (filter: SenderFilter) => void;
  customDateRange: { from?: string, to?: string };
  setCustomDateRange: (range: { from?: string, to?: string }) => void;
  downloadPath: string;
  setDownloadPath: (path: string) => void;
  sendAutoMessage: boolean;
  setSendAutoMessage: (enabled: boolean) => void;
  downloadMedia: () => Promise<{success: boolean, error?: string}>;
  downloadProgress: {
    inProgress: boolean;
    filesProcessed: number;
    totalFiles: number;
    currentFile?: string;
  };
  
  // Templates
  templates: Template[];
  selectedTemplateId: number | null;
  setSelectedTemplateId: (id: number | null) => void;
  createTemplate: (template: { name: string, content: string }) => Promise<void>;
  updateTemplate: (id: number, template: { name: string, content: string }) => Promise<void>;
  deleteTemplate: (id: number) => Promise<void>;
  refreshTemplates: () => Promise<void>;
  
  // Messages
  unreadMessages: Message[];
  markMessageAsRead: (id: number) => Promise<void>;
  markAllMessagesAsRead: (chatId: number) => Promise<void>;
  sendMessage: (chatId: number, content: string, schedule?: {
    enabled: boolean,
    date?: string,
    time?: string,
    repeat?: "never" | "daily" | "weekly" | "monthly"
  }) => Promise<{success: boolean, error?: string}>;
  refreshMessages: () => Promise<void>;
  
  // Download History
  downloadHistory: Download[];
  deleteDownloadRecord: (id: number) => Promise<void>;
  refreshDownloadHistory: () => Promise<void>;
  
  // Settings
  settings: Settings | null;
  updateSettings: (settings: Partial<Settings>) => Promise<void>;
}

const WhatsAppContext = createContext<WhatsAppContextType | undefined>(undefined);

export const WhatsAppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Connection state
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
  const [qrCode, setQRCode] = useState<string | null>(null);
  
  // Chats
  const [chats, setChats] = useState<Chat[]>([]);
  const [selectedChatIds, setSelectedChatIds] = useState<number[]>([]);
  const [chatFilter, setChatFilter] = useState<'all' | 'groups' | 'contacts'>('all');
  
  // Media Download
  const [selectedFileTypes, setSelectedFileTypes] = useState<FileType[]>(['image', 'video']);
  const [timeFilter, setTimeFilter] = useState<TimeFilter>('yesterday');
  const [senderFilter, setSenderFilter] = useState<SenderFilter>('all');
  const [customDateRange, setCustomDateRange] = useState<{ from?: string, to?: string }>({});
  const [downloadPath, setDownloadPath] = useState<string>('');
  const [sendAutoMessage, setSendAutoMessage] = useState<boolean>(false);
  const [downloadProgress, setDownloadProgress] = useState({
    inProgress: false,
    filesProcessed: 0,
    totalFiles: 0,
    currentFile: undefined as string | undefined,
  });
  
  // Templates
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplateId, setSelectedTemplateId] = useState<number | null>(null);
  
  // Messages
  const [unreadMessages, setUnreadMessages] = useState<Message[]>([]);
  
  // Download History
  const [downloadHistory, setDownloadHistory] = useState<Download[]>([]);
  
  // Settings
  const [settings, setSettings] = useState<Settings | null>(null);
  
  // Initialize data on mount
  useEffect(() => {
    const initializeData = async () => {
      await Promise.all([
        refreshConnectionStatus(),
        refreshChats(),
        refreshTemplates(),
        refreshMessages(),
        refreshDownloadHistory(),
        refreshSettings()
      ]);
    };
    
    initializeData();
  }, []);
  
  // Connection methods
  const refreshConnectionStatus = async () => {
    try {
      const response = await apiRequest('GET', '/api/connection/status');
      const data = await response.json();
      setConnectionStatus(data.status);
      
      if (data.status === 'connecting') {
        await refreshQRCode();
      }
    } catch (error) {
      console.error('Error refreshing connection status:', error);
    }
  };
  
  const connect = async () => {
    try {
      await apiRequest('POST', '/api/connection/connect');
      setConnectionStatus('connecting');
      await refreshQRCode();
    } catch (error) {
      console.error('Error connecting to WhatsApp:', error);
    }
  };
  
  const disconnect = async () => {
    try {
      await apiRequest('POST', '/api/connection/disconnect');
      setConnectionStatus('disconnected');
      setQRCode(null);
    } catch (error) {
      console.error('Error disconnecting from WhatsApp:', error);
    }
  };
  
  const refreshQRCode = async () => {
    try {
      const response = await apiRequest('GET', '/api/connection/qrcode');
      const data = await response.json();
      setQRCode(data.qrCode);
    } catch (error) {
      console.error('Error refreshing QR code:', error);
    }
  };
  
  // Chat methods
  const refreshChats = async () => {
    try {
      const response = await apiRequest('GET', '/api/chats');
      const data = await response.json();
      setChats(data);
    } catch (error) {
      console.error('Error refreshing chats:', error);
    }
  };
  
  const toggleChatSelection = (chatId: number) => {
    setSelectedChatIds(prev => {
      if (prev.includes(chatId)) {
        return prev.filter(id => id !== chatId);
      } else {
        return [...prev, chatId];
      }
    });
  };
  
  const selectAllChats = () => {
    const filtered = chatFilter === 'all' 
      ? chats 
      : chats.filter(chat => chat.type === (chatFilter === 'groups' ? 'group' : 'contact'));
    
    setSelectedChatIds(filtered.map(chat => chat.id));
  };
  
  const unselectAllChats = () => {
    setSelectedChatIds([]);
  };
  
  // Media Download methods
  const toggleFileType = (type: FileType) => {
    setSelectedFileTypes(prev => {
      if (prev.includes(type)) {
        return prev.filter(t => t !== type);
      } else {
        return [...prev, type];
      }
    });
  };
  
  const downloadMedia = async () => {
    if (selectedChatIds.length === 0 || selectedFileTypes.length === 0) {
      return {
        success: false,
        error: 'Please select at least one chat and file type'
      };
    }
    
    try {
      setDownloadProgress({
        inProgress: true,
        filesProcessed: 0,
        totalFiles: 0
      });
      
      const response = await apiRequest('POST', '/api/media/download', {
        chatIds: selectedChatIds,
        fileTypes: selectedFileTypes,
        timeFilter,
        senderFilter,
        customDateRange: timeFilter === 'custom' ? customDateRange : undefined,
        downloadPath,
        sendAutoMessage,
        autoMessageTemplateId: sendAutoMessage ? selectedTemplateId : undefined
      });
      
      const result = await response.json();
      
      setDownloadProgress({
        inProgress: false,
        filesProcessed: result.filesDownloaded,
        totalFiles: result.filesDownloaded,
        currentFile: undefined
      });
      
      // Refresh download history
      await refreshDownloadHistory();
      
      return {
        success: result.success,
        error: result.error
      };
    } catch (error) {
      console.error('Error downloading media:', error);
      
      setDownloadProgress({
        inProgress: false,
        filesProcessed: 0,
        totalFiles: 0,
        currentFile: undefined
      });
      
      return {
        success: false,
        error: (error as Error).message
      };
    }
  };
  
  // Template methods
  const refreshTemplates = async () => {
    try {
      const response = await apiRequest('GET', '/api/templates');
      const data = await response.json();
      setTemplates(data);
    } catch (error) {
      console.error('Error refreshing templates:', error);
    }
  };
  
  const createTemplate = async (template: { name: string, content: string }) => {
    try {
      await apiRequest('POST', '/api/templates', {
        ...template,
        createdAt: new Date(),
        updatedAt: new Date()
      });
      await refreshTemplates();
    } catch (error) {
      console.error('Error creating template:', error);
    }
  };
  
  const updateTemplate = async (id: number, template: { name: string, content: string }) => {
    try {
      await apiRequest('PUT', `/api/templates/${id}`, {
        ...template,
        updatedAt: new Date()
      });
      await refreshTemplates();
    } catch (error) {
      console.error('Error updating template:', error);
    }
  };
  
  const deleteTemplate = async (id: number) => {
    try {
      await apiRequest('DELETE', `/api/templates/${id}`);
      await refreshTemplates();
      if (selectedTemplateId === id) {
        setSelectedTemplateId(null);
      }
    } catch (error) {
      console.error('Error deleting template:', error);
    }
  };
  
  // Message methods
  const refreshMessages = async () => {
    try {
      const response = await apiRequest('GET', '/api/messages');
      const data = await response.json();
      setUnreadMessages(data.filter((message: Message) => !message.isRead));
    } catch (error) {
      console.error('Error refreshing messages:', error);
    }
  };
  
  const markMessageAsRead = async (id: number) => {
    try {
      await apiRequest('POST', `/api/messages/mark-read/${id}`);
      await refreshMessages();
    } catch (error) {
      console.error('Error marking message as read:', error);
    }
  };
  
  const markAllMessagesAsRead = async (chatId: number) => {
    try {
      await apiRequest('POST', `/api/messages/mark-all-read/${chatId}`);
      await refreshMessages();
    } catch (error) {
      console.error('Error marking all messages as read:', error);
    }
  };
  
  const sendMessage = async (
    chatId: number,
    content: string,
    schedule?: {
      enabled: boolean,
      date?: string,
      time?: string,
      repeat?: "never" | "daily" | "weekly" | "monthly"
    }
  ) => {
    try {
      const response = await apiRequest('POST', '/api/messages/send', {
        chatId,
        content,
        schedule
      });
      
      const result = await response.json();
      await refreshMessages();
      
      return {
        success: result.success,
        error: result.error
      };
    } catch (error) {
      console.error('Error sending message:', error);
      
      return {
        success: false,
        error: (error as Error).message
      };
    }
  };
  
  // Download History methods
  const refreshDownloadHistory = async () => {
    try {
      const response = await apiRequest('GET', '/api/downloads');
      const data = await response.json();
      setDownloadHistory(data);
    } catch (error) {
      console.error('Error refreshing download history:', error);
    }
  };
  
  const deleteDownloadRecord = async (id: number) => {
    try {
      await apiRequest('DELETE', `/api/downloads/${id}`);
      await refreshDownloadHistory();
    } catch (error) {
      console.error('Error deleting download record:', error);
    }
  };
  
  // Settings methods
  const refreshSettings = async () => {
    try {
      const response = await apiRequest('GET', '/api/settings');
      const data = await response.json();
      setSettings(data);
      if (data && data.downloadPath) {
        setDownloadPath(data.downloadPath);
      }
    } catch (error) {
      console.error('Error refreshing settings:', error);
    }
  };
  
  const updateSettings = async (newSettings: Partial<Settings>) => {
    try {
      await apiRequest('PUT', '/api/settings', newSettings);
      await refreshSettings();
    } catch (error) {
      console.error('Error updating settings:', error);
    }
  };
  
  const value: WhatsAppContextType = {
    connectionStatus,
    qrCode,
    connect,
    disconnect,
    refreshQRCode,
    
    chats,
    selectedChatIds,
    toggleChatSelection,
    selectAllChats,
    unselectAllChats,
    refreshChats,
    chatFilter,
    setChatFilter,
    
    selectedFileTypes,
    toggleFileType,
    timeFilter,
    setTimeFilter,
    senderFilter,
    setSenderFilter,
    customDateRange,
    setCustomDateRange,
    downloadPath,
    setDownloadPath,
    sendAutoMessage,
    setSendAutoMessage,
    downloadMedia,
    downloadProgress,
    
    templates,
    selectedTemplateId,
    setSelectedTemplateId,
    createTemplate,
    updateTemplate,
    deleteTemplate,
    refreshTemplates,
    
    unreadMessages,
    markMessageAsRead,
    markAllMessagesAsRead,
    sendMessage,
    refreshMessages,
    
    downloadHistory,
    deleteDownloadRecord,
    refreshDownloadHistory,
    
    settings,
    updateSettings
  };
  
  return (
    <WhatsAppContext.Provider value={value}>
      {children}
    </WhatsAppContext.Provider>
  );
};

export const useWhatsApp = (): WhatsAppContextType => {
  const context = useContext(WhatsAppContext);
  if (context === undefined) {
    throw new Error('useWhatsApp must be used within a WhatsAppProvider');
  }
  return context;
};
