import { apiRequest } from './queryClient';
import type { ConnectionStatus, FileType, TimeFilter, SenderFilter } from '@shared/schema';

export async function getConnectionStatus(): Promise<ConnectionStatus> {
  try {
    const response = await apiRequest('GET', '/api/connection/status');
    const data = await response.json();
    return data.status;
  } catch (error) {
    console.error('Error getting connection status:', error);
    return 'error';
  }
}

export async function connectToWhatsApp(): Promise<boolean> {
  try {
    await apiRequest('POST', '/api/connection/connect');
    return true;
  } catch (error) {
    console.error('Error connecting to WhatsApp:', error);
    return false;
  }
}

export async function disconnectFromWhatsApp(): Promise<boolean> {
  try {
    await apiRequest('POST', '/api/connection/disconnect');
    return true;
  } catch (error) {
    console.error('Error disconnecting from WhatsApp:', error);
    return false;
  }
}

export async function getQRCode(): Promise<string | null> {
  try {
    const response = await apiRequest('GET', '/api/connection/qrcode');
    const data = await response.json();
    return data.qrCode;
  } catch (error) {
    console.error('Error getting QR code:', error);
    return null;
  }
}

export async function downloadMedia(options: {
  chatIds: number[];
  fileTypes: FileType[];
  timeFilter: TimeFilter;
  senderFilter: SenderFilter;
  customDateRange?: { from?: string; to?: string };
  downloadPath: string;
  sendAutoMessage: boolean;
  autoMessageTemplateId?: number;
}): Promise<{ success: boolean; downloadId?: number; error?: string; filesDownloaded: number }> {
  try {
    const response = await apiRequest('POST', '/api/media/download', options);
    return await response.json();
  } catch (error) {
    console.error('Error downloading media:', error);
    return {
      success: false,
      error: (error as Error).message,
      filesDownloaded: 0
    };
  }
}

export async function sendMessage(
  chatId: number,
  content: string,
  schedule?: {
    enabled: boolean;
    date?: string;
    time?: string;
    repeat?: 'never' | 'daily' | 'weekly' | 'monthly';
  }
): Promise<{ success: boolean; error?: string }> {
  try {
    const response = await apiRequest('POST', '/api/messages/send', {
      chatId,
      content,
      schedule
    });
    return await response.json();
  } catch (error) {
    console.error('Error sending message:', error);
    return {
      success: false,
      error: (error as Error).message
    };
  }
}

export async function openDownloadFolder(path: string): Promise<boolean> {
  try {
    // In Electron, you would use the shell.openPath API
    // For now, we'll just log it
    console.log('Opening folder:', path);
    return true;
  } catch (error) {
    console.error('Error opening folder:', error);
    return false;
  }
}

export async function selectDownloadFolder(): Promise<string | null> {
  try {
    // In Electron, you would use the dialog.showOpenDialog API
    // For now, return a dummy path
    return 'C:\\Users\\Username\\Downloads\\WhatsApp Media';
  } catch (error) {
    console.error('Error selecting folder:', error);
    return null;
  }
}
