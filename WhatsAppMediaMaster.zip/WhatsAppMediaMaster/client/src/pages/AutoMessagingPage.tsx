import React from 'react';
import TemplateList from '@/components/auto-messaging/TemplateList';
import TemplateEditor from '@/components/auto-messaging/TemplateEditor';

const AutoMessagingPage: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <TemplateList />
      <TemplateEditor />
    </div>
  );
};

export default AutoMessagingPage;
