import React, { useEffect } from 'react';
import { useWhatsApp } from '@/context/WhatsAppContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

const ConnectionPage: React.FC = () => {
  const { connectionStatus, qrCode, connect, disconnect, refreshQRCode } = useWhatsApp();
  
  // Auto-refresh QR code every 30 seconds if in connecting state
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (connectionStatus === 'connecting') {
      timer = setInterval(() => {
        refreshQRCode();
      }, 30000); // 30 seconds
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [connectionStatus, refreshQRCode]);
  
  return (
    <div className="fluent-card p-8 max-w-3xl mx-auto text-center">
      <i className="fas fa-qrcode text-8xl text-primary mb-6"></i>
      <h2 className="text-2xl font-semibold mb-4">Connect to WhatsApp</h2>
      <p className="text-neutral-dark mb-8">Scan the QR code with your phone to connect WhatsApp Web</p>
      
      <div className="flex justify-center mb-8">
        {connectionStatus === 'connecting' && qrCode ? (
          <div className="w-64 h-64 border-2 border-gray-300 flex items-center justify-center">
            <img src={qrCode} alt="WhatsApp QR Code" className="w-full h-full" />
          </div>
        ) : (
          <div className="w-64 h-64 border-2 border-dashed border-gray-300 flex items-center justify-center">
            {connectionStatus === 'connecting' ? (
              <div className="text-center">
                <i className="fas fa-circle-notch fa-spin text-4xl text-gray-400 mb-2"></i>
                <p className="text-gray-400">Loading QR Code...</p>
              </div>
            ) : connectionStatus === 'connected' ? (
              <div className="text-center">
                <i className="fas fa-check-circle text-4xl text-success mb-2"></i>
                <p className="text-gray-600">Connected to WhatsApp</p>
              </div>
            ) : (
              <span className="text-gray-400">QR Code will appear here</span>
            )}
          </div>
        )}
      </div>
      
      <div className="flex flex-col items-center">
        {connectionStatus === 'connecting' && (
          <>
            <Button 
              className="bg-primary hover:bg-primary-dark text-white font-semibold py-2 px-6 rounded flex items-center mb-4"
              onClick={refreshQRCode}
            >
              <i className="fas fa-sync-alt mr-2"></i> Refresh QR Code
            </Button>
            <p className="text-sm text-gray-500">QR code will expire in 45 seconds</p>
          </>
        )}
        
        {connectionStatus === 'connected' && (
          <Button 
            className="bg-error hover:bg-error/90 text-white font-semibold py-2 px-6 rounded flex items-center mb-4"
            onClick={disconnect}
          >
            <i className="fas fa-sign-out-alt mr-2"></i> Disconnect
          </Button>
        )}
        
        {(connectionStatus === 'disconnected' || connectionStatus === 'error') && (
          <Button 
            className="bg-primary hover:bg-primary-dark text-white font-semibold py-2 px-6 rounded flex items-center mb-4"
            onClick={connect}
          >
            <i className="fas fa-plug mr-2"></i> Connect to WhatsApp
          </Button>
        )}
        
        {connectionStatus === 'error' && (
          <p className="text-sm text-error mt-2">
            Error connecting to WhatsApp. Please try again.
          </p>
        )}
      </div>
    </div>
  );
};

export default ConnectionPage;
