import React from 'react';
import StatsOverview from '@/components/download-history/StatsOverview';
import HistoryTable from '@/components/download-history/HistoryTable';
import { Card } from '@/components/ui/card';

const DownloadHistoryPage: React.FC = () => {
  return (
    <Card className="p-4">
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-semibold">Download History</h3>
      </div>
      
      <StatsOverview />
      <HistoryTable />
    </Card>
  );
};

export default DownloadHistoryPage;
