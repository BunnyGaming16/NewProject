import React from 'react';
import ChatList from '@/components/media-download/ChatList';
import DownloadOptions from '@/components/media-download/DownloadOptions';
import DownloadStatus from '@/components/media-download/DownloadStatus';

const MediaDownloadPage: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <ChatList />
      <DownloadOptions />
      <DownloadStatus />
    </div>
  );
};

export default MediaDownloadPage;
