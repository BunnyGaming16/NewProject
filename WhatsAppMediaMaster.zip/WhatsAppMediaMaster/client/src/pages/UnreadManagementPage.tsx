import React from 'react';
import UnreadList from '@/components/unread-management/UnreadList';
import ResponseOptions from '@/components/unread-management/ResponseOptions';
import ConversationHistory from '@/components/unread-management/ConversationHistory';

const UnreadManagementPage: React.FC = () => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <UnreadList />
      <ResponseOptions />
      <ConversationHistory />
    </div>
  );
};

export default UnreadManagementPage;
