import express from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { WhatsAppAutomation } from "./whatsapp";
import { insertChatSchema, insertTemplateSchema, insertDownloadSchema, insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize WhatsApp automation
  const whatsAppAutomation = new WhatsAppAutomation();

  // API routes
  const apiRouter = express.Router();

  // WhatsApp Connection routes
  apiRouter.get("/connection/status", async (req, res) => {
    const status = await whatsAppAutomation.getConnectionStatus();
    res.json({ status });
  });

  apiRouter.post("/connection/connect", async (req, res) => {
    try {
      await whatsAppAutomation.connect();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.post("/connection/disconnect", async (req, res) => {
    try {
      await whatsAppAutomation.disconnect();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.get("/connection/qrcode", async (req, res) => {
    try {
      const qrCode = await whatsAppAutomation.getQRCode();
      if (qrCode) {
        res.json({ qrCode });
      } else {
        res.status(404).json({ error: "QR code not available" });
      }
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Chat routes
  apiRouter.get("/chats", async (req, res) => {
    try {
      const chats = await storage.getChats();
      res.json(chats);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.get("/chats/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const chat = await storage.getChatById(id);
      if (chat) {
        res.json(chat);
      } else {
        res.status(404).json({ error: "Chat not found" });
      }
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.post("/chats", async (req, res) => {
    try {
      const chatData = insertChatSchema.parse(req.body);
      const chat = await storage.createChat(chatData);
      res.status(201).json(chat);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  // Template routes
  apiRouter.get("/templates", async (req, res) => {
    try {
      const templates = await storage.getTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.get("/templates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const template = await storage.getTemplateById(id);
      if (template) {
        res.json(template);
      } else {
        res.status(404).json({ error: "Template not found" });
      }
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.post("/templates", async (req, res) => {
    try {
      const templateData = insertTemplateSchema.parse(req.body);
      const template = await storage.createTemplate(templateData);
      res.status(201).json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  apiRouter.put("/templates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const templateData = insertTemplateSchema.partial().parse(req.body);
      const template = await storage.updateTemplate(id, templateData);
      if (template) {
        res.json(template);
      } else {
        res.status(404).json({ error: "Template not found" });
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  apiRouter.delete("/templates/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteTemplate(id);
      if (success) {
        res.json({ success });
      } else {
        res.status(404).json({ error: "Template not found" });
      }
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Message routes
  apiRouter.get("/messages", async (req, res) => {
    try {
      const chatId = req.query.chatId ? parseInt(req.query.chatId as string) : undefined;
      const messages = await storage.getMessages(chatId);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.post("/messages/mark-read/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const message = await storage.markMessageAsRead(id);
      if (message) {
        res.json(message);
      } else {
        res.status(404).json({ error: "Message not found" });
      }
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.post("/messages/mark-all-read/:chatId", async (req, res) => {
    try {
      const chatId = parseInt(req.params.chatId);
      const success = await storage.markAllChatMessagesAsRead(chatId);
      res.json({ success });
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Download media routes
  apiRouter.post("/media/download", async (req, res) => {
    try {
      const schema = z.object({
        chatIds: z.array(z.number()),
        fileTypes: z.array(z.enum(["image", "video", "audio", "document"])),
        timeFilter: z.enum(["all", "today", "yesterday", "last7days", "last30days", "custom"]),
        senderFilter: z.enum(["all", "excludeOwn", "onlyOwn"]),
        customDateRange: z.object({
          from: z.string().optional(),
          to: z.string().optional(),
        }).optional(),
        downloadPath: z.string(),
        sendAutoMessage: z.boolean(),
        autoMessageTemplateId: z.number().optional(),
      });

      const downloadOptions = schema.parse(req.body);
      const result = await whatsAppAutomation.downloadMedia(downloadOptions);
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  // Download history routes
  apiRouter.get("/downloads", async (req, res) => {
    try {
      const downloads = await storage.getDownloads();
      res.json(downloads);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.delete("/downloads/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteDownload(id);
      if (success) {
        res.json({ success });
      } else {
        res.status(404).json({ error: "Download record not found" });
      }
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  // Auto messaging routes
  apiRouter.post("/messages/send", async (req, res) => {
    try {
      const schema = z.object({
        chatId: z.number(),
        content: z.string(),
        schedule: z.object({
          enabled: z.boolean(),
          date: z.string().optional(),
          time: z.string().optional(),
          repeat: z.enum(["never", "daily", "weekly", "monthly"]).optional(),
        }).optional(),
      });

      const messageData = schema.parse(req.body);
      const result = await whatsAppAutomation.sendMessage(
        messageData.chatId,
        messageData.content,
        messageData.schedule
      );
      res.json(result);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: error.errors });
      } else {
        res.status(500).json({ error: (error as Error).message });
      }
    }
  });

  // Settings routes
  apiRouter.get("/settings", async (req, res) => {
    try {
      const settings = await storage.getSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });

  apiRouter.put("/settings", async (req, res) => {
    try {
      const settingsData = req.body;
      const settings = await storage.updateSettings(settingsData);
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: (error as Error).message });
    }
  });
  
  // Register all API routes with /api prefix
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
