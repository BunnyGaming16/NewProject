import { 
  chats, 
  templates, 
  downloads, 
  messages, 
  settings,
  type Chat, 
  type InsertChat, 
  type Template, 
  type InsertTemplate, 
  type Download, 
  type InsertDownload, 
  type Message, 
  type InsertMessage, 
  type Settings, 
  type InsertSettings,
  type FileType,
  type WhatsAppMediaFile
} from "@shared/schema";

export interface IStorage {
  // Chat operations
  getChats(): Promise<Chat[]>;
  getChatById(id: number): Promise<Chat | undefined>;
  createChat(chat: InsertChat): Promise<Chat>;
  updateChat(id: number, chat: Partial<InsertChat>): Promise<Chat | undefined>;
  deleteChat(id: number): Promise<boolean>;
  
  // Template operations
  getTemplates(): Promise<Template[]>;
  getTemplateById(id: number): Promise<Template | undefined>;
  createTemplate(template: InsertTemplate): Promise<Template>;
  updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template | undefined>;
  deleteTemplate(id: number): Promise<boolean>;
  
  // Download operations
  getDownloads(): Promise<Download[]>;
  getDownloadById(id: number): Promise<Download | undefined>;
  createDownload(download: InsertDownload): Promise<Download>;
  updateDownload(id: number, download: Partial<InsertDownload>): Promise<Download | undefined>;
  deleteDownload(id: number): Promise<boolean>;
  
  // Message operations
  getMessages(chatId?: number): Promise<Message[]>;
  getMessageById(id: number): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  updateMessage(id: number, message: Partial<InsertMessage>): Promise<Message | undefined>;
  markMessageAsRead(id: number): Promise<Message | undefined>;
  markAllChatMessagesAsRead(chatId: number): Promise<boolean>;
  
  // Settings operations
  getSettings(): Promise<Settings | undefined>;
  updateSettings(settings: Partial<InsertSettings>): Promise<Settings | undefined>;
}

export class MemStorage implements IStorage {
  private chatStore: Map<number, Chat>;
  private templateStore: Map<number, Template>;
  private downloadStore: Map<number, Download>;
  private messageStore: Map<number, Message>;
  private settingsStore: Settings | undefined;
  
  private chatId = 1;
  private templateId = 1;
  private downloadId = 1;
  private messageId = 1;
  
  constructor() {
    this.chatStore = new Map();
    this.templateStore = new Map();
    this.downloadStore = new Map();
    this.messageStore = new Map();
    
    // Initialize with some default templates
    this.createTemplate({
      name: "Thank You",
      content: "Thank you for sharing these materials. I've received them and will review them soon.",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    
    this.createTemplate({
      name: "Reminder",
      content: "Just a friendly reminder about our meeting tomorrow at 3 PM. Please confirm if you'll be attending.",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    
    this.createTemplate({
      name: "Follow Up",
      content: "I wanted to follow up on our previous conversation. Have you had a chance to review the proposal?",
      createdAt: new Date(),
      updatedAt: new Date(),
    });
    
    // Initialize with default settings
    this.settingsStore = {
      id: 1,
      downloadPath: "C:\\Users\\Username\\Downloads\\WhatsApp Media",
      autoMessageEnabled: false,
      autoMessageTemplateId: 1,
      organizeFoldersByDate: true,
      organizeFoldersByChat: true,
      organizeFoldersByType: true,
    };
  }

  // Chat operations
  async getChats(): Promise<Chat[]> {
    return Array.from(this.chatStore.values());
  }

  async getChatById(id: number): Promise<Chat | undefined> {
    return this.chatStore.get(id);
  }

  async createChat(chat: InsertChat): Promise<Chat> {
    const id = this.chatId++;
    const newChat: Chat = { ...chat, id, lastUpdated: new Date() };
    this.chatStore.set(id, newChat);
    return newChat;
  }

  async updateChat(id: number, chat: Partial<InsertChat>): Promise<Chat | undefined> {
    const existingChat = this.chatStore.get(id);
    if (!existingChat) return undefined;
    
    const updatedChat: Chat = { ...existingChat, ...chat, lastUpdated: new Date() };
    this.chatStore.set(id, updatedChat);
    return updatedChat;
  }

  async deleteChat(id: number): Promise<boolean> {
    return this.chatStore.delete(id);
  }

  // Template operations
  async getTemplates(): Promise<Template[]> {
    return Array.from(this.templateStore.values());
  }

  async getTemplateById(id: number): Promise<Template | undefined> {
    return this.templateStore.get(id);
  }

  async createTemplate(template: InsertTemplate): Promise<Template> {
    const id = this.templateId++;
    const newTemplate: Template = { ...template, id };
    this.templateStore.set(id, newTemplate);
    return newTemplate;
  }

  async updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template | undefined> {
    const existingTemplate = this.templateStore.get(id);
    if (!existingTemplate) return undefined;
    
    const updatedTemplate: Template = { 
      ...existingTemplate, 
      ...template, 
      updatedAt: new Date() 
    };
    this.templateStore.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteTemplate(id: number): Promise<boolean> {
    return this.templateStore.delete(id);
  }

  // Download operations
  async getDownloads(): Promise<Download[]> {
    return Array.from(this.downloadStore.values());
  }

  async getDownloadById(id: number): Promise<Download | undefined> {
    return this.downloadStore.get(id);
  }

  async createDownload(download: InsertDownload): Promise<Download> {
    const id = this.downloadId++;
    const newDownload: Download = { ...download, id };
    this.downloadStore.set(id, newDownload);
    return newDownload;
  }

  async updateDownload(id: number, download: Partial<InsertDownload>): Promise<Download | undefined> {
    const existingDownload = this.downloadStore.get(id);
    if (!existingDownload) return undefined;
    
    const updatedDownload: Download = { ...existingDownload, ...download };
    this.downloadStore.set(id, updatedDownload);
    return updatedDownload;
  }

  async deleteDownload(id: number): Promise<boolean> {
    return this.downloadStore.delete(id);
  }

  // Message operations
  async getMessages(chatId?: number): Promise<Message[]> {
    const messages = Array.from(this.messageStore.values());
    if (chatId) {
      return messages.filter(message => message.chatId === chatId);
    }
    return messages;
  }

  async getMessageById(id: number): Promise<Message | undefined> {
    return this.messageStore.get(id);
  }

  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const newMessage: Message = { ...message, id };
    this.messageStore.set(id, newMessage);
    return newMessage;
  }

  async updateMessage(id: number, message: Partial<InsertMessage>): Promise<Message | undefined> {
    const existingMessage = this.messageStore.get(id);
    if (!existingMessage) return undefined;
    
    const updatedMessage: Message = { ...existingMessage, ...message };
    this.messageStore.set(id, updatedMessage);
    return updatedMessage;
  }

  async markMessageAsRead(id: number): Promise<Message | undefined> {
    const message = this.messageStore.get(id);
    if (!message) return undefined;
    
    message.isRead = true;
    this.messageStore.set(id, message);
    return message;
  }

  async markAllChatMessagesAsRead(chatId: number): Promise<boolean> {
    const messages = Array.from(this.messageStore.values())
      .filter(message => message.chatId === chatId && !message.isRead);
    
    for (const message of messages) {
      message.isRead = true;
      this.messageStore.set(message.id, message);
    }
    
    return true;
  }

  // Settings operations
  async getSettings(): Promise<Settings | undefined> {
    return this.settingsStore;
  }

  async updateSettings(settings: Partial<InsertSettings>): Promise<Settings | undefined> {
    if (!this.settingsStore) return undefined;
    
    this.settingsStore = { ...this.settingsStore, ...settings };
    return this.settingsStore;
  }
}

export const storage = new MemStorage();
