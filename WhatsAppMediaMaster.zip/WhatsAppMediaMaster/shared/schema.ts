import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Chat schema for storing WhatsApp chats
export const chats = pgTable("chats", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'contact' or 'group'
  avatar: text("avatar"),
  lastMessage: text("last_message"),
  unreadCount: integer("unread_count").default(0),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

// Template schema for auto-messaging templates
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Media downloads history
export const downloads = pgTable("downloads", {
  id: serial("id").primaryKey(),
  chatId: integer("chat_id").notNull(),
  dateDownloaded: timestamp("date_downloaded").defaultNow(),
  fileCount: integer("file_count").notNull(),
  fileTypes: jsonb("file_types").notNull(), // {images: 10, videos: 5, etc}
  totalSize: integer("total_size").notNull(), // in bytes
  path: text("path").notNull(),
  status: text("status").notNull(), // 'completed', 'failed', 'in_progress'
});

// Message schema for unread messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  chatId: integer("chat_id").notNull(),
  sender: text("sender").notNull(),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  isRead: boolean("is_read").default(false),
  hasMedia: boolean("has_media").default(false),
  mediaType: text("media_type"), // 'image', 'video', 'audio', 'document'
  mediaPath: text("media_path"),
});

// Settings for the application
export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  downloadPath: text("download_path").notNull(),
  autoMessageEnabled: boolean("auto_message_enabled").default(false),
  autoMessageTemplateId: integer("auto_message_template_id"),
  organizeFoldersByDate: boolean("organize_folders_by_date").default(true),
  organizeFoldersByChat: boolean("organize_folders_by_chat").default(true),
  organizeFoldersByType: boolean("organize_folders_by_type").default(true),
});

// Insert schemas using drizzle-zod
export const insertChatSchema = createInsertSchema(chats);
export const insertTemplateSchema = createInsertSchema(templates);
export const insertDownloadSchema = createInsertSchema(downloads);
export const insertMessageSchema = createInsertSchema(messages);
export const insertSettingsSchema = createInsertSchema(settings);

// Types for TypeScript
export type Chat = typeof chats.$inferSelect;
export type InsertChat = typeof chats.$inferInsert;

export type Template = typeof templates.$inferSelect;
export type InsertTemplate = typeof templates.$inferInsert;

export type Download = typeof downloads.$inferSelect;
export type InsertDownload = typeof downloads.$inferInsert;

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

export type Settings = typeof settings.$inferSelect;
export type InsertSettings = typeof settings.$inferInsert;

// Additional custom types for the application
export type FileType = "image" | "video" | "audio" | "document";

export type TimeFilter = "all" | "today" | "yesterday" | "last7days" | "last30days" | "custom";

export type SenderFilter = "all" | "excludeOwn" | "onlyOwn";

export type ConnectionStatus = "disconnected" | "connecting" | "connected" | "error";

export type WhatsAppMediaFile = {
  id: string;
  name: string;
  type: FileType;
  size: number;
  url: string;
  timestamp: Date;
  sender: string;
  path?: string;
};
